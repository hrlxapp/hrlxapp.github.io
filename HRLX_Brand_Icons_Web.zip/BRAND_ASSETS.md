# HRLX Brand Icon Assets

All eight source PNG files are preserved pixel-for-pixel and only renamed.

Path:
`assets/images/brand/`

Files:
- hrlx-purple.png — default
- hrlx-blue.png
- hrlx-cyan.png
- hrlx-green.png
- hrlx-pink.png
- hrlx-red.png
- hrlx-orange.png
- hrlx-gold.png

All are 1024×1024 transparent PNGs with identical geometry and alignment.
